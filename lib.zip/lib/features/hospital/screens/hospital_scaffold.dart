// lib/features/hospital/widgets/hospital_scaffold.dart
import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_dimensions.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../auth/controllers/auth_controller.dart';
import 'package:get/get.dart';

class HospitalScaffold extends StatelessWidget {
  final String title;
  final Widget body;

  const HospitalScaffold({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width >= 600;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        scrolledUnderElevation: 1,
        leading: isWide
            ? null
            : Builder(
                builder: (ctx) => IconButton(
                  icon: const Icon(
                    Icons.menu_rounded,
                    color: AppColors.textPrimary,
                  ),
                  onPressed: () => Scaffold.of(ctx).openDrawer(),
                ),
              ),
        title: Text(title, style: AppTextStyles.heading3),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: AppDimensions.paddingBase),
            child: GetBuilder<AuthController>(
              builder: (authCtrl) => Row(
                children: [
                  Text(
                    authCtrl.currentUser?.email ?? '',
                    style: AppTextStyles.bodySmall,
                  ),
                  const SizedBox(width: AppDimensions.paddingS),
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: AppColors.hospitalPrimary,
                    child: Text(
                      (authCtrl.currentUser?.name.isNotEmpty == true)
                          ? authCtrl.currentUser!.name
                                .substring(0, 2)
                                .toUpperCase()
                          : 'DR',
                      style: const TextStyle(
                        color: AppColors.textWhite,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      body: body,
    );
  }
}

